class ApiResponse {
  constructor(msg, payload) {
    this.msg = msg;
    this.payload = payload;
  }
}

module.exports = ApiResponse;
